package com.all.spring.mybatis.dao;

public class IDao {

}
