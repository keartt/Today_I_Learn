package com.all.spring.mybatis.dao;

public class ContentDao {

}
