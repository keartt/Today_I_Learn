package com.all.spring.dto;

public class ContentDto {

}
