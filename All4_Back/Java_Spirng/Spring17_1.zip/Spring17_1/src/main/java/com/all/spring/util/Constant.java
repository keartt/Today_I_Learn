package com.all.spring.util;

import org.springframework.jdbc.core.JdbcTemplate;

public class Constant {

		public static JdbcTemplate template;
}
